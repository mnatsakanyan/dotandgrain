import editor from "./editor.js";
editor.default.preload();
